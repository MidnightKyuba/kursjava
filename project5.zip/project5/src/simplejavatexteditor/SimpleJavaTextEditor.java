package simplejavatexteditor;

import javax.swing.*;

public class SimpleJavaTextEditor extends JTextPane {

    private static final long serialVersionUID = 1L;
    public final static  String AUTHOR_EMAIL = "jakubkittel59@gmail.com";
    public final static String NAME = "Edytor";
    public final static String EDITOR_EMAIL = "jakubkittel59@gmail.com";
    public final static double VERSION = 0.8;


    public static void main(String[] args) {
        new UI().setVisible(true);
    }
}
