package simplejavatexteditor;

import javax.swing.*;

public class FEdit {

    public static void clear(JTextArea textArea) {
        textArea.setText("");
    }
}
